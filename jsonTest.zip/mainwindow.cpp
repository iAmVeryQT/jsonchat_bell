#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QJsonDocument>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(&soketQt, SIGNAL(readyRead()), this, SLOT(onReceive()));

    ui->AddressEdit->setText("boss2d.com");
    roomNum = "123";
}

MainWindow::~MainWindow()
{
    delete ui;
}


/*void MainWindow::on_aabbcc_textChanged()
{

    QString a= ui->aabbcc->toPlainText();

    if(a.right(1)=="\n")
    {
        a.resize(a.size()-1);
        //QMessageBox(QMessageBox::Information,"hello world~~",a).exec();
        soketQt.connectToHost(a,10125);
        if(soketQt.waitForConnected(5000))
           {
                QMessageBox(QMessageBox::Information,"hello world~~",a).exec();
           }
        else
          {
                QMessageBox(QMessageBox::Information,"error!!!",a).exec();

          }

        ui->aabbcc->setText(a);

        QTextCursor cursor = ui->aabbcc->textCursor();
        cursor.movePosition(QTextCursor::End);
        ui->aabbcc->setTextCursor(cursor);
    }

}*/

/*void MainWindow::on_lineEdit_returnPressed()
{
    QString a= ui->TalkEdit->text();
     QString json = "#json begin {";
     //json += "{";
     json += "'type':'chat',";
     json += "'room':'r123',";
     json += "'text':'"+a+"'";
     json += "} #json end";

     soketQt.write(json.toUtf8().constData());
}*/

void MainWindow::onReceive()
{
    QTcpSocket* Peer = (QTcpSocket*) sender();
       qint64 PacketSize = Peer->bytesAvailable();

       if(0 < PacketSize)
       {
           char* PacketBuffer = new char[PacketSize + 1];
           Peer->read(PacketBuffer, PacketSize);
           PacketBuffer[PacketSize] = '\0';
           //QMessageBox(QMessageBox::Information,"hello",PacketBuffer).exec();


           QString jasonString = PacketBuffer;
           jasonString.remove("#json begin");
           jasonString.remove("#json end");

            QJsonDocument a = QJsonDocument::fromJson(jasonString.toUtf8());
            QString b = a["text"].toString("");
            QString c = a["name"].toString("noName");
            //ui->TalkList->addItem("["+c+"]"+b);

            if(true)
            {
                QIcon img("../image/in-love.png"); //역슬래쉬 쓰려면 두번 써야한다.  "//"
                QListWidgetItem* item = new QListWidgetItem(img, b);
                ui->TalkList->addItem(item); //qt에서 알아서 delete해줌
            }
            else{
                ui->TalkList->addItem("["+c+"]"+b);
            }


           //ui->TalkList->addItem(jasonString);
           delete[] PacketBuffer;

           //ui->TalkList->addItem("ab");
       }


}

void MainWindow::on_AddressEdit_textChanged(const QString &arg1)
{
    address = arg1;

}

void MainWindow::on_ConnectBtn_clicked()
{

    soketQt.connectToHost(address,10125);
    if(soketQt.waitForConnected(5000))
       {
            //QMessageBox(QMessageBox::Information,"hello world~~",address).exec();
            ui->TalkEdit->setEnabled(true);
            ui->TalkList->setEnabled(true);
       }
    else
      {
            QMessageBox(QMessageBox::Information,"error!!!",address).exec();

      }
}

void MainWindow::on_TalkEdit_textEdited(const QString &arg1)
{
    textMessage = arg1;

}

void MainWindow::on_TalkEdit_returnPressed()
{
    QString json = "#json begin {";
     //json += "{";
     json += "'type':'chat',";
     json += "'room':'"+roomNum+"',";
     json += "'name':'"+name+"',"; //필드를 지워버리면 noName이 나온다..
     json += "'text':'"+textMessage+"'";
     json += "} #json end";

     soketQt.write(json.toUtf8().constData());

     ui->TalkEdit->clear();

}

void MainWindow::on_UserName_textEdited(const QString &arg1)
{
    name = arg1;
}

void MainWindow::on_RoomName_textEdited(const QString &arg1)
{
    roomNum = arg1;
}


